module.exports = {

    MID: 'UzlnSt68784401432697',
    WEBSITE: 'WEBSTAGING',
    CHANNEL_ID: 'WEB',
    INDUSTRY_TYPE_ID: 'Retail',
    MERCHANT_KEY: '0utN6krgczGa_hgd'

}